![version](https://img.shields.io/badge/version-v1.0-blue.svg)
[![Build Status](https://travis-ci.org/MahShaaban/colocr_app.svg?branch=master)](https://travis-ci.org/MahShaaban/colocr_app)
[![status](https://img.shields.io/badge/shinyapps.io-running-green.svg)](https://mahshaaban.shinyapps.io/colocr_app2/)  

# colocr_app

A shiny app for conducting co-localization analysis.
